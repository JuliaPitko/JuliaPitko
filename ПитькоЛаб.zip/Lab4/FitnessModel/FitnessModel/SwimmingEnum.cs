﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FitnessModel
{
    /// <summary>
    /// Перечисление стиля плавания
    /// </summary>
    public enum SwimmingEnum
    {

        SlowBrace = 1,
        QuickCrawl,
        SlowСrawl
    }
}
